package com.tuc.tubs.entity;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Bureau.class)
public class BureauIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
