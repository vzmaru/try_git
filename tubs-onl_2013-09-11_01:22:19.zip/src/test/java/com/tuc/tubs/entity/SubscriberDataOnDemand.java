package com.tuc.tubs.entity;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Subscriber.class)
public class SubscriberDataOnDemand {
}
