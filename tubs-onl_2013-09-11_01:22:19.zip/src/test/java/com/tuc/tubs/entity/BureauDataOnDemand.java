package com.tuc.tubs.entity;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Bureau.class)
public class BureauDataOnDemand {
}
