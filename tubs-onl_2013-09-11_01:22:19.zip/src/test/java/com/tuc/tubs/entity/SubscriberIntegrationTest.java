package com.tuc.tubs.entity;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Subscriber.class)
public class SubscriberIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
