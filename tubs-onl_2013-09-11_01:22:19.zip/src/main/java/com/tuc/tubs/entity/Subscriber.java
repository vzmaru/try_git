package com.tuc.tubs.entity;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.jpa.activerecord.RooJpaActiveRecord;
import org.springframework.roo.addon.tostring.RooToString;
import javax.validation.constraints.NotNull;

@RooJavaBean
@RooToString
@RooJpaActiveRecord
public class Subscriber {

    /**
     */
    @NotNull
    private String subscriberId;

    /**
     */
    @NotNull
    private String subscriberName;

    /**
     */
    @NotNull
    private String owningBureau;

    /**
     */
    @NotNull
    private String city;

    /**
     */
    @NotNull
    private String zState;
}
