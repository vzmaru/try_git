package com.tuc.tubs.web;
import com.tuc.tubs.entity.Bureau;
import org.springframework.roo.addon.web.mvc.controller.scaffold.RooWebScaffold;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/bureaus")
@Controller
@RooWebScaffold(path = "bureaus", formBackingObject = Bureau.class)
public class BureauController {
}
